'use strict';

var utils = require('../utils/writer.js');
var Default = require('../service/DefaultService');

module.exports.bookingBooking_idDELETE = function bookingBooking_idDELETE (req, res, next) {
  var booking_id = req.swagger.params['booking_id'].value;
  Default.bookingBooking_idDELETE(booking_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.bookingBooking_idGET = function bookingBooking_idGET (req, res, next) {
  var booking_id = req.swagger.params['booking_id'].value;
  Default.bookingBooking_idGET(booking_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.bookingBooking_idPUT = function bookingBooking_idPUT (req, res, next) {
  var booking_id = req.swagger.params['booking_id'].value;
  var booking_put_request_body = req.swagger.params['booking_put_request_body'].value;
  Default.bookingBooking_idPUT(booking_id,booking_put_request_body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.bookingBooking_idPaymentPOST = function bookingBooking_idPaymentPOST (req, res, next) {
  var booking_id = req.swagger.params['booking_id'].value;
  var payment_post_request_body = req.swagger.params['payment_post_request_body'].value;
  Default.bookingBooking_idPaymentPOST(booking_id,payment_post_request_body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.bookingPOST = function bookingPOST (req, res, next) {
  var booking_post_request_body = req.swagger.params['booking_post_request_body'].value;
  Default.bookingPOST(booking_post_request_body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.searchGET = function searchGET (req, res, next) {
  var servicename = req.swagger.params['servicename'].value;
  var category = req.swagger.params['category'].value;
  var email = req.swagger.params['email'].value;
  Default.searchGET(servicename,category,email)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.serviceDELETE = function serviceDELETE (req, res, next) {
  var servicename = req.swagger.params['servicename'].value;
  var category = req.swagger.params['category'].value;
  Default.serviceDELETE(servicename,category)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.servicePOST = function servicePOST (req, res, next) {
  var service_post_request_body = req.swagger.params['service_post_request_body'].value;
  Default.servicePOST(service_post_request_body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.servicePUT = function servicePUT (req, res, next) {
  var service_put_request_body = req.swagger.params['service_put_request_body'].value;
  Default.servicePUT(service_put_request_body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.serviceService_idCommentComment_idGET = function serviceService_idCommentComment_idGET (req, res, next) {
  var service_id = req.swagger.params['service_id'].value;
  var comment_id = req.swagger.params['comment_id'].value;
  Default.serviceService_idCommentComment_idGET(service_id,comment_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.serviceService_idCommentComment_idPUT = function serviceService_idCommentComment_idPUT (req, res, next) {
  var comment_put_request_body = req.swagger.params['comment_put_request_body'].value;
  var service_id = req.swagger.params['service_id'].value;
  var comment_id = req.swagger.params['comment_id'].value;
  Default.serviceService_idCommentComment_idPUT(comment_put_request_body,service_id,comment_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.serviceService_idCommentPOST = function serviceService_idCommentPOST (req, res, next) {
  var service_id = req.swagger.params['service_id'].value;
  var comment_post_request_body = req.swagger.params['comment_post_request_body'].value;
  Default.serviceService_idCommentPOST(service_id,comment_post_request_body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.serviceService_idGET = function serviceService_idGET (req, res, next) {
  var service_id = req.swagger.params['service_id'].value;
  Default.serviceService_idGET(service_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.serviceService_idRatePOST = function serviceService_idRatePOST (req, res, next) {
  var service_id = req.swagger.params['service_id'].value;
  var rate_post_request_body = req.swagger.params['rate_post_request_body'].value;
  Default.serviceService_idRatePOST(service_id,rate_post_request_body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.serviceService_idRateRate_idPUT = function serviceService_idRateRate_idPUT (req, res, next) {
  var rate_put_request_body = req.swagger.params['rate_put_request_body'].value;
  var service_id = req.swagger.params['service_id'].value;
  var rate_id = req.swagger.params['rate_id'].value;
  Default.serviceService_idRateRate_idPUT(rate_put_request_body,service_id,rate_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.userPOST = function userPOST (req, res, next) {
  var user_post_request_body = req.swagger.params['user_post_request_body'].value;
  Default.userPOST(user_post_request_body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.userUsernameGET = function userUsernameGET (req, res, next) {
  var username = req.swagger.params['username'].value;
  Default.userUsernameGET(username)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.userUsernamePUT = function userUsernamePUT (req, res, next) {
  var username = req.swagger.params['username'].value;
  var user_put_request_body = req.swagger.params['user_put_request_body'].value;
  Default.userUsernamePUT(username,user_put_request_body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
