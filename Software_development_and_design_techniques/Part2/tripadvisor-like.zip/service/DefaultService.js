'use strict';


/**
 *
 * booking_id Integer 
 * returns booking_delete_200_response
 **/
exports.bookingBooking_idDELETE = function(booking_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = { };
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * booking_id Integer 
 * returns booking_get_200_response
 **/
exports.bookingBooking_idGET = function(booking_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "[{\"amount\":150,\"date\":\"18/2/2018 12:32\",\"type\":\"credit\"}]";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * booking_id Integer 
 * booking_put_request_body Booking_put_request_body  (optional)
 * returns booking_put_200_response
 **/
exports.bookingBooking_idPUT = function(booking_id,booking_put_request_body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = { };
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * -  Possible payment options are 'credit', 'paypal'
 *
 * booking_id Integer 
 * payment_post_request_body Payment_post_request_body  (optional)
 * returns payment_post_default_response
 **/
exports.bookingBooking_idPaymentPOST = function(booking_id,payment_post_request_body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = { };
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * booking_post_request_body Booking_post_request_body 
 * returns booking_post_200_response
 **/
exports.bookingPOST = function(booking_post_request_body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = { };
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * -  The user is able to search for services in the website using servicename and/or category filter, view their general details -   The user is able to search for services in the website using servicename and/or category filter, view their general details -   The user is able to search for other user in the website using email, view their general details
 *
 * servicename String  (optional)
 * category String  (optional)
 * email String  (optional)
 * returns search_get_200_response
 **/
exports.searchGET = function(servicename,category,email) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = { };
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * servicename String  (optional)
 * category String  (optional)
 * returns service_delete_200_response
 **/
exports.serviceDELETE = function(servicename,category) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = { };
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * service_post_request_body Service_post_request_body  (optional)
 * returns service_post_200_response
 **/
exports.servicePOST = function(service_post_request_body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "service" : "[{\"id\":30,\"category\":\"Hotel\",\"servicename\":\"Grand Hotel\",\"description\":\"Grand hotel near Larisa\",\"date of release\":\"05/06/2010\",\"location\":\"Larisa\",\"telephone\":\"2410228811\",\"email\":\"grandhotel@info.gr\",\"tag\":\"hotels\",\"photo\":\"http://photo.com/myphoto\",\"cost\":1500.1}]"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * service_put_request_body Service_put_request_body  (optional)
 * returns service_put_200_response
 **/
exports.servicePUT = function(service_put_request_body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "[{\"servicename\":\"NOLAN\",\"description\":\"2 Michelin stars\",\"category\":\"Restaurant\"}]";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * service_id Integer 
 * comment_id Integer 
 * returns comment_get_default_response
 **/
exports.serviceService_idCommentComment_idGET = function(service_id,comment_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "[{\"date\":\"8/2/2017 12:32\",\"comment\":\"a comment\",\"comment_id\":189}]";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * comment_put_request_body Comment_put_request_body 
 * service_id Integer 
 * comment_id Integer 
 * no response value expected for this operation
 **/
exports.serviceService_idCommentComment_idPUT = function(comment_put_request_body,service_id,comment_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 *
 * service_id Integer 
 * comment_post_request_body Comment_post_request_body  (optional)
 * returns comment_post_default_response
 **/
exports.serviceService_idCommentPOST = function(service_id,comment_post_request_body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = { };
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * service_id Integer 
 * returns service_get_200_response
 **/
exports.serviceService_idGET = function(service_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "service" : "[{\"id\":30,\"category\":\"Hotel\",\"servicename\":\"Grand Hotel\",\"description\":\"Grand hotel near Larisa\",\"date of release\":\"05/06/2010\",\"location\":\"Larisa\",\"telephone\":\"2410228811\",\"email\":\"grandhotel@info.gr\",\"tag\":\"hotels\",\"photo\":\"http://photo.com/myphoto\",\"cost\":1500.1}]"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * service_id Integer 
 * rate_post_request_body Rate_post_request_body  (optional)
 * returns rate_post_200_response
 **/
exports.serviceService_idRatePOST = function(service_id,rate_post_request_body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = { };
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * rate_put_request_body Rate_put_request_body 
 * service_id Integer 
 * rate_id Integer 
 * no response value expected for this operation
 **/
exports.serviceService_idRateRate_idPUT = function(rate_put_request_body,service_id,rate_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 *
 * user_post_request_body User_post_request_body 
 * returns user_post_default_response
 **/
exports.userPOST = function(user_post_request_body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "[{\"username\":\"Ioa\",\"first name\":\"Ioannis\",\"last name\":\"Katsikavelas\",\"email\":\"katsikave@ece.auth.gr\",\"id\":250,\"date of birth\":\"12/02/1993\",\"sex\":\"male\",\"photo\":\"http://photo.com/myphoto\"}]";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * username String 
 * returns user_get_default_response
 **/
exports.userUsernameGET = function(username) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "user" : "[{\"username\":\"Ioa\",\"first name\":\"Ioannis\",\"last name\":\"Katsikavelas\",\"email\":\"katsikave@ece.auth.gr\",\"id\":250,\"date of birth\":\"12/02/1993\",\"sex\":\"male\",\"photo\":\"http://photo.com/myphoto\"}]"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 *
 * username String 
 * user_put_request_body User_put_request_body 
 * returns user_put_default_response
 **/
exports.userUsernamePUT = function(username,user_put_request_body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "[{\"username\":\"Ioannis93\",\"first name\":\"Ioannis\",\"last name\":\"Katsikavelas\",\"email\":\"katsikave@ece.auth.gr\",\"id\":250,\"date of birth\":\"12/02/1993\",\"sex\":\"male\",\"photo\":\"http://photo.com/myphoto\"}]";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

